from datetime import datetime

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from modules.database.user_db import (
    get_user_role_db,
    get_quota_record_db,
    update_quota_counts_db,
    increment_search_used_db,
    increment_request_used_db,
    add_quota_limits_db,
)
from modules.allowance.referral import get_user_referral_stats


def check_and_reset_quota(user_id):
    """Checks if a new calendar day has started and resets daily usage counts to 0."""
    today_str = datetime.now().strftime('%Y-%m-%d')
    row = get_quota_record_db(user_id)

    if row:
        _, _, _, _, last_reset = row
        if last_reset != today_str:
            update_quota_counts_db(user_id, 0, 0, today_str)


def can_user_search(user_id):
    """Validates if a user has remaining search quota for the day."""
    role = get_user_role_db(user_id)
    if role in ['Admin', 'Owner']:
        return True  # Unlimited access

    check_and_reset_quota(user_id)
    row = get_quota_record_db(user_id)
    if not row:
        return True

    searches_used, searches_limit, _, _, _ = row
    return searches_used < searches_limit


def can_user_request(user_id):
    """Validates if a user has remaining request quota for the day."""
    role = get_user_role_db(user_id)
    if role in ['Admin', 'Owner']:
        return True  # Unlimited access

    check_and_reset_quota(user_id)
    row = get_quota_record_db(user_id)
    if not row:
        return True

    _, _, requests_used, requests_limit, _ = row
    return requests_used < requests_limit


def deduct_search_quota(user_id):
    """Deducts 1 search allowance ONLY after a successful search."""
    role = get_user_role_db(user_id)
    if role in ['Admin', 'Owner']:
        return  # Unlimited users do not consume quota
    increment_search_used_db(user_id)


def deduct_request_quota(user_id):
    """Deducts 1 request allowance ONLY after a successful request submission."""
    role = get_user_role_db(user_id)
    if role in ['Admin', 'Owner']:
        return  # Unlimited users do not consume quota
    increment_request_used_db(user_id)


def get_user_quota_summary(user_id):
    """Retrieves and formats the user's role and remaining quotas for the /quota command."""
    check_and_reset_quota(user_id)
    role = get_user_role_db(user_id)
    row = get_quota_record_db(user_id)

    if role in ['Admin', 'Owner']:
        return {
            "role": role,
            "unlimited": True,
            "searches_left": "Unlimited",
            "searches_limit": "Unlimited",
            "requests_left": "Unlimited",
            "requests_limit": "Unlimited",
        }

    if row:
        searches_used, searches_limit, requests_used, requests_limit, _ = row
        searches_left = max(0, searches_limit - searches_used)
        requests_left = max(0, requests_limit - requests_used)
        return {
            "role": role,
            "unlimited": False,
            "searches_left": searches_left,
            "searches_limit": searches_limit,
            "requests_left": requests_left,
            "requests_limit": requests_limit,
        }
    return None


def gift_quota(admin_user_id, target_user_id, search_bonus=0, request_bonus=0):
    """Allows Admins or Owners to increase a target user's quota limits via /gift <n>."""
    admin_role = get_user_role_db(admin_user_id)
    if admin_role not in ['Admin', 'Owner']:
        return False, "❌ You do not have permission to use the gift command."

    add_quota_limits_db(target_user_id, search_bonus, request_bonus)
    return True, f"🎁 Successfully added +{search_bonus} search limit and +{request_bonus} request limit to user `{target_user_id}`."


async def quota_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Telegram command handler for /quota"""
    user_id = update.effective_user.id
    summary = get_user_quota_summary(user_id)

    if not summary:
        await update.message.reply_text("⚠️ Could not retrieve your quota record.")
        return

    if summary["unlimited"]:
        await update.message.reply_text(
            f"👤 **Your Role:** {summary['role']}\n"
            f"♾️ **Status:** Unlimited searches and requests."
        )
    else:
        await update.message.reply_text(
            f"👤 **Your Role:** {summary['role']}\n\n"
            f"🔍 **Searches Remaining:** {summary['searches_left']} / {summary['searches_limit']}\n"
            f"📥 **Requests Remaining:** {summary['requests_left']} / {summary['requests_limit']}\n\n"
            f"*(Quotas reset automatically every day)*",
            parse_mode="Markdown"
        )


async def gift_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Telegram command handler for /gift <user_id> <searches> <requests>"""
    admin_id = update.effective_user.id
    args = context.args

    if len(args) < 3:
        await update.message.reply_text(
            "⚠️ **Usage:** `/gift <user_id> <search_bonus> <request_bonus>`",
            parse_mode="Markdown"
        )
        return

    try:
        target_id = int(args[0])
        search_bonus = int(args[1])
        request_bonus = int(args[2])
    except ValueError:
        await update.message.reply_text(
            "⚠️ Invalid numbers provided.\n"
            "**Usage:** `/gift <user_id> <search_bonus> <request_bonus>`",
            parse_mode="Markdown"
        )
        return

    success, message = gift_quota(admin_id, target_id, search_bonus, request_bonus)
    await update.message.reply_text(message, parse_mode="Markdown")


async def refer_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Telegram command handler for /refer to generate link, view invite history, and share."""
    user = update.effective_user
    bot_username = context.bot.username

    referral_link = f"https://t.me/{bot_username}?start=ref_{user.id}"
    stats = get_user_referral_stats(user.id)
    total_invites = stats["total_invites"]
    referred_list = stats["referred_list"]

    text = (
        f"🔗 **Your Referral Dashboard**\n\n"
        f"📌 **Your Link:**\n`{referral_link}`\n\n"
        f"📊 **Total Friends Invited:** `{total_invites}`\n"
        f"🎁 **Bonus Earned:** `+{total_invites * 10}` Searches & Requests\n\n"
    )

    if referred_list:
        text += "👥 **Invited Users:**\n"
        for r_id, r_name, r_uname, timestamp in referred_list[:10]:
            name_display = r_name or f"User {r_id}"
            text += f"• {name_display} (ID: `{r_id}`)\n"
        if total_invites > 10:
            text += f"\n*(Showing latest 10 of {total_invites} invites)*\n"
    else:
        text += "💡 *You haven't invited anyone yet. Share your link to start earning bonuses!*"

    text += f"\n\n*When a new user starts via your link, both of you get +10 searches & requests!*"

    share_text = "Join Mastermind Bot and let's earn bonus searches & requests!"
    share_url = f"https://t.me/share/url?url={referral_link}&text={share_text}"

    keyboard = [
        [InlineKeyboardButton("📤 Refer More & Share Link", url=share_url)]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=reply_markup)
