import os
import sqlite3
import json

DB_PATH = "configuration.db"

def init_config_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS bot_config (
            key TEXT PRIMARY KEY,
            value_type TEXT NOT NULL,
            content TEXT NOT NULL,
            fallback_env TEXT
        )
    """)
    conn.commit()
    conn.close()

def get_config(key, default="", fallback_env=None):
    init_config_db()
    
    # 1. Check database first
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT content FROM bot_config WHERE key = ?", (key,))
    row = cursor.fetchone()
    conn.close()
    
    if row:
        return row[0]
        
    # 2. Fallback to environment / env.txt if specified
    if fallback_env:
        env_val = os.getenv(fallback_env)
        if env_val:
            return env_val
            
    return default

def set_config(key, value_type, content, fallback_env=None):
    init_config_db()
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT OR REPLACE INTO bot_config (key, value_type, content, fallback_env)
        VALUES (?, ?, ?, ?)
    """, (key, value_type, content, fallback_env))
    conn.commit()
    conn.close()

def get_all_configs():
    init_config_db()
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT key, value_type, content, fallback_env FROM bot_config")
    rows = cursor.fetchall()
    conn.close()
    return rows
